import json
import requests

def lambda_handler(event, context):
    print("Received event: " + json.dumps(event, indent=2))
    message = event['Records'][0]['Sns']['Message']
    print("From SNS: " + message)

    messageDict = json.loads(message)
    if messageDict['status'] == 'FAILED':
        slackColor = 'danger'
        slackValue = messageDict['errorInformation']
    else:
        slackColor = 'good'
        slackValue = messageDict['status']

    url = 'https://hooks.slack.com/services/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'
    payload = {
        'channel': '#gnavi',
        'username': 'CodeDeploy',
        'icon_emoji': ':shipit:',
        'attachments': [
            {
                'fallback': 'code deploy status : ' + messageDict['deploymentGroupName'] + ' : ' + messageDict['status'],
                'color': slackColor,
                'title': messageDict['deploymentGroupName'] + ' : '  + messageDict['status'],
                'text': slackValue
            }
        ]
    }
    headers = {'content-type': 'application/json'}
    r = requests.post(url, data=json.dumps(payload), headers=headers)

    return message

